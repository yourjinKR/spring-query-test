# Cardinality 실험 자동 분석

상태 completed: 측정 50회, 계측 유효 50회, 정상 50회. 워밍업 50회 제외.

실행별 통계의 중앙값 [관측 최솟값, 최댓값]. 동일 반복에서 양쪽 모두 정상인 쌍만 주요 비교에 사용한다.


| 단계 | 댓글/첨부 | 정상 쌍 | 예상 v1 rows | 실측 v1 rows | 예상 v2 rows | 실측 v2 rows | v1/v2 rows | 행 감소율 |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| confirm | 1/1 | 5/5 | 10 | 10.000 [10.000, 10.000] | 30 | 30.000 [30.000, 30.000] | 0.333 | -200.000% |
| confirm | 5/1 | 5/5 | 50 | 50.000 [50.000, 50.000] | 70 | 70.000 [70.000, 70.000] | 0.714 | -40.000% |
| confirm | 5/5 | 5/5 | 250 | 250.000 [250.000, 250.000] | 110 | 110.000 [110.000, 110.000] | 2.273 | 56.000% |
| confirm | 20/5 | 5/5 | 1000 | 1000.000 [1000.000, 1000.000] | 260 | 260.000 [260.000, 260.000] | 3.846 | 74.000% |
| confirm | 100/20 | 5/5 | 20000 | 20000.000 [20000.000, 20000.000] | 1210 | 1210.000 [1210.000, 1210.000] | 16.529 | 93.950% |

## confirm: 1/1

| 전략 | HTTP p50 ms | HTTP p95 ms | HTTP p99 ms | 완료 RPS | 성공 RPS |
|---|---:|---:|---:|---:|---:|
| v1 | 1.083 [1.075, 1.360] | 1.978 [1.902, 2.432] | 2.984 [2.362, 4.061] | 677.933 [552.804, 698.867] | 677.933 [552.804, 698.867] |
| v2 | 1.371 [1.363, 1.499] | 2.441 [2.397, 2.755] | 3.116 [3.037, 4.616] | 566.181 [506.084, 567.533] | 566.181 [506.084, 567.533] |

| 전략 | fetchAndAssemble p50 ms | JDBC execute p50 ms | assembly p50 ms | acquire 평균 ms | usage 평균 ms |
|---|---:|---:|---:|---:|---:|
| v1 | 0.336 [0.333, 0.539] | 0.000 [0.000, 0.000] | 0.005 [0.005, 0.005] | 0.001 [0.001, 0.001] | 0.197 [0.170, 0.493] |
| v2 | 0.631 [0.628, 0.685] | 0.000 [0.000, 0.000] | 0.006 [0.005, 0.006] | 0.001 [0.001, 0.001] | 0.565 [0.546, 0.758] |

쌍별 p95 v2/v1 1.239 [0.997, 1.284]. v2 유리 1쌍, v1 유리 4쌍.


## confirm: 5/1

| 전략 | HTTP p50 ms | HTTP p95 ms | HTTP p99 ms | 완료 RPS | 성공 RPS |
|---|---:|---:|---:|---:|---:|
| v1 | 1.193 [1.182, 1.488] | 2.131 [2.070, 2.541] | 2.710 [2.664, 3.443] | 622.500 [515.384, 630.700] | 622.500 [515.384, 630.700] |
| v2 | 1.397 [1.378, 1.879] | 2.541 [2.431, 3.378] | 3.188 [3.088, 6.582] | 543.385 [406.047, 556.785] | 543.385 [406.047, 556.785] |

| 전략 | fetchAndAssemble p50 ms | JDBC execute p50 ms | assembly p50 ms | acquire 평균 ms | usage 평균 ms |
|---|---:|---:|---:|---:|---:|
| v1 | 0.429 [0.423, 0.639] | 0.000 [0.000, 0.000] | 0.007 [0.007, 0.008] | 0.001 [0.001, 0.001] | 0.283 [0.252, 0.704] |
| v2 | 0.640 [0.629, 0.834] | 0.000 [0.000, 0.000] | 0.008 [0.007, 0.009] | 0.001 [0.001, 0.001] | 0.607 [0.568, 1.115] |

쌍별 p95 v2/v1 1.219 [1.074, 1.329]. v2 유리 0쌍, v1 유리 5쌍.


## confirm: 5/5

| 전략 | HTTP p50 ms | HTTP p95 ms | HTTP p99 ms | 완료 RPS | 성공 RPS |
|---|---:|---:|---:|---:|---:|
| v1 | 1.705 [1.504, 1.873] | 2.892 [2.490, 3.281] | 4.072 [3.251, 4.967] | 439.167 [405.033, 506.784] | 439.167 [405.033, 506.784] |
| v2 | 1.442 [1.374, 2.502] | 2.546 [2.465, 10.572] | 3.455 [3.148, 19.826] | 521.567 [239.616, 547.552] | 521.567 [239.616, 547.552] |

| 전략 | fetchAndAssemble p50 ms | JDBC execute p50 ms | assembly p50 ms | acquire 평균 ms | usage 평균 ms |
|---|---:|---:|---:|---:|---:|
| v1 | 0.781 [0.706, 0.951] | 0.000 [0.000, 0.000] | 0.014 [0.014, 0.015] | 0.001 [0.001, 0.001] | 1.125 [0.920, 1.224] |
| v2 | 0.654 [0.626, 1.136] | 0.000 [0.000, 0.000] | 0.009 [0.009, 0.013] | 0.001 [0.001, 0.001] | 0.656 [0.562, 2.184] |

쌍별 p95 v2/v1 0.951 [0.776, 3.452]. v2 유리 3쌍, v1 유리 2쌍.


## confirm: 20/5

| 전략 | HTTP p50 ms | HTTP p95 ms | HTTP p99 ms | 완료 RPS | 성공 RPS |
|---|---:|---:|---:|---:|---:|
| v1 | 2.908 [2.577, 3.301] | 4.644 [3.994, 8.991] | 6.796 [5.332, 19.300] | 274.700 [210.107, 310.669] | 274.700 [210.107, 310.669] |
| v2 | 1.472 [1.437, 2.743] | 2.655 [2.536, 8.684] | 3.426 [3.217, 15.950] | 491.833 [230.674, 504.517] | 491.833 [230.674, 504.517] |

| 전략 | fetchAndAssemble p50 ms | JDBC execute p50 ms | assembly p50 ms | acquire 평균 ms | usage 평균 ms |
|---|---:|---:|---:|---:|---:|
| v1 | 1.777 [1.611, 2.072] | 1.000 [1.000, 1.000] | 0.037 [0.036, 0.039] | 0.001 [0.001, 0.001] | 2.268 [1.806, 3.104] |
| v2 | 0.686 [0.674, 1.235] | 0.000 [0.000, 0.000] | 0.016 [0.016, 0.022] | 0.001 [0.001, 0.002] | 0.738 [0.690, 2.166] |

쌍별 p95 v2/v1 0.621 [0.303, 1.244]. v2 유리 4쌍, v1 유리 1쌍.


## confirm: 100/20

| 전략 | HTTP p50 ms | HTTP p95 ms | HTTP p99 ms | 완료 RPS | 성공 RPS |
|---|---:|---:|---:|---:|---:|
| v1 | 32.052 [30.466, 35.585] | 126.868 [118.282, 139.523] | 141.633 [136.467, 201.371] | 21.913 [19.252, 22.917] | 21.913 [19.252, 22.917] |
| v2 | 2.108 [2.006, 2.350] | 3.359 [3.120, 4.248] | 4.401 [4.058, 8.425] | 310.823 [270.791, 326.533] | 310.823 [270.791, 326.533] |

| 전략 | fetchAndAssemble p50 ms | JDBC execute p50 ms | assembly p50 ms | acquire 평균 ms | usage 평균 ms |
|---|---:|---:|---:|---:|---:|
| v1 | 30.342 [28.649, 33.726] | 18.000 [16.000, 20.000] | 0.908 [0.897, 0.940] | 0.001 [0.001, 0.002] | 43.205 [41.315, 49.279] |
| v2 | 1.066 [1.022, 1.180] | 0.000 [0.000, 0.000] | 0.053 [0.052, 0.056] | 0.001 [0.001, 0.001] | 1.207 [1.138, 1.478] |

쌍별 p95 v2/v1 0.028 [0.022, 0.033]. v2 유리 5쌍, v1 유리 0쌍.

## 관측 역전 구간

- confirm (30s): 1/1: p50 v1, p95 mixed; 5/1: p50 mixed, p95 v1; 5/5: p50 mixed, p95 mixed; 20/5: p50 v2, p95 mixed; 100/20: p50 v2, p95 v2
- p50: 1/1 (10 JOIN rows, v1) → 20/5 (1000 JOIN rows, v2). 정확한 전환점을 추정하지 않는다.
- p95: 5/1 (50 JOIN rows, v1) → 100/20 (20000 JOIN rows, v2). 정확한 전환점을 추정하지 않는다.

## 해석 범위

- One complete execution is one replicate; headline metrics use matched clean repeat pairs and unweighted run median [observed min,max]. Ranges are not confidence intervals; percentiles are not pooled.
- Cardinality is the paired comments/attachments scenario. Post count=200, IDs=1..10, bodyBytes=1024, seed=42, UNIFORM, direct DB route, pool=10 and VU=1 are fixed.
- totalRows counts returned flat rows, not database scan rows or network bytes. jdbcExecuteMs is JDBC execute-call duration, not pure PostgreSQL execution time.
- fetchAndAssembleMs excludes HTTP serialization; assemblyMs excludes materializing JDBC results. Different timers cannot be subtracted to establish causal CPU/network contributions.
- HTTP p99 is auxiliary; executions with fewer than 1000 successful responses are flagged in raw analysis. Closed-loop RPS is completed work at VU 1, not maximum service capacity.
- Crossover bands join opposite consistent winners in observed scenarios; exact thresholds are not fitted. Scenario paths vary two child counts and are not a universal scalar threshold.
- Exploration and confirmation stages, incompatible duration/IDs/timeouts/API settings remain separate. Elapsed time above duration + timeout + 2000ms is invalid.
- Optional CPU/heap observations and approximate GC/allocation deltas reuse the existing monitor within each pool window; missing observations remain unavailable and do not invalidate HTTP measurements. CPU is 100%=one core; sampled heap maxima are not exact process peaks.
